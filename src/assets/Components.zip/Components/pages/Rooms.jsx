import React from 'react';

export const Rooms = () => {
  return  <div>Rooms</div>;
};
