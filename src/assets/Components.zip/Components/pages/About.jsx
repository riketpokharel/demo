import React from 'react';

export const About = () => {
  return <div>
    <div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
    beatae voluptatibus magni? Est?
    </div>
  
  <div>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. 
  Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
  beatae voluptatibus magni? Est?
</div>;
<div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
    beatae voluptatibus magni? Est?
  </div>;
  <div>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. 
  Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
  beatae voluptatibus magni? Est?
</div>;
<div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
    beatae voluptatibus magni? Est?
  </div>;
  <div>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. 
  Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
  beatae voluptatibus magni? Est?
</div>;
<div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
    beatae voluptatibus magni? Est?
  </div>;
  <div>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. 
  Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
  beatae voluptatibus magni? Est?
</div>;
<div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
    beatae voluptatibus magni? Est?
  </div>;
  <div>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. 
  Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
  beatae voluptatibus magni? Est?
</div>;
<div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
    beatae voluptatibus magni? Est?
  </div>;
  <div>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. 
  Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
  beatae voluptatibus magni? Est?
</div>;
<div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Sapiente, voluptatum! Veniam est, tenetur magnam laboriosam ipsam, iure quod sunt iste eum voluptatem non sint explicabo soluta, 
    beatae voluptatibus magni? Est?
  </div>;
  </div>;
};
