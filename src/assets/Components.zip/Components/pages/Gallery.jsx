import React from 'react';

export const Gallery = () => {
  return <div>Gallery</div>;
};
