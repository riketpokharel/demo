import React from 'react';

export const Facilities = () => {
  return <div>Facilities</div>;
};
